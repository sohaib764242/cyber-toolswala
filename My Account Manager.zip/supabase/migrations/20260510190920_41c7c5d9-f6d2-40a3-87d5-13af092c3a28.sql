ALTER TABLE public.records
ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'unpaid'
CHECK (payment_status IN ('paid', 'partial', 'unpaid'));