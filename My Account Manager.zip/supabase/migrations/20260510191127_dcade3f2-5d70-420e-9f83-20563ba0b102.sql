ALTER TABLE public.records
ADD COLUMN reminder_date DATE,
ADD COLUMN reminder_note TEXT;

CREATE INDEX idx_records_reminder_date ON public.records(user_id, reminder_date) WHERE reminder_date IS NOT NULL;