CREATE TABLE public.records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  mobile TEXT,
  to_pay NUMERIC NOT NULL DEFAULT 0,
  to_receive NUMERIC NOT NULL DEFAULT 0,
  invoices_sent INTEGER NOT NULL DEFAULT 0,
  payment_received NUMERIC NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own records select" ON public.records FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "own records insert" ON public.records FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own records update" ON public.records FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "own records delete" ON public.records FOR DELETE USING (auth.uid() = user_id);

CREATE TRIGGER records_set_updated_at
BEFORE UPDATE ON public.records
FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();