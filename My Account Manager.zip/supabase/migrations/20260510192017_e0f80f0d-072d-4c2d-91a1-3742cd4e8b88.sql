ALTER TABLE public.records
ADD COLUMN account TEXT,
ADD COLUMN payment_method TEXT;