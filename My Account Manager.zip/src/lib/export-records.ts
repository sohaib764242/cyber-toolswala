import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export type RecordRow = {
  name: string;
  mobile: string | null;
  account: string | null;
  payment_method: string | null;
  tool: string | null;
  to_pay: number | string;
  to_receive: number | string;
  invoices_sent: number;
  payment_received: number | string;
  payment_status: string | null;
  reminder_date: string | null;
  reminder_note: string | null;
  notes: string | null;
};

const num = (v: number | string) => Number(v) || 0;
const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);

const triggerDownload = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
};

const csvCell = (v: unknown) => {
  const s = v == null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function exportRecordsCSV(records: RecordRow[]) {
  const headers = [
    "Name", "Mobile", "Tool", "Account", "Payment method", "You owe", "Owed to you", "Invoices sent",
    "Received", "Status", "Reminder date", "Reminder note", "Notes",
  ];
  const rows = records.map((r) => [
    r.name, r.mobile ?? "", r.tool ?? "", r.account ?? "", r.payment_method ?? "",
    num(r.to_pay).toFixed(2), num(r.to_receive).toFixed(2),
    r.invoices_sent, num(r.payment_received).toFixed(2),
    r.payment_status ?? "unpaid", r.reminder_date ?? "", r.reminder_note ?? "", r.notes ?? "",
  ]);
  const csv = [headers, ...rows].map((row) => row.map(csvCell).join(",")).join("\n");
  const blob = new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8" });
  triggerDownload(blob, `records-${new Date().toISOString().slice(0, 10)}.csv`);
}

export function exportRecordsPDF(records: RecordRow[]) {
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
  const today = new Date().toLocaleDateString();

  const totals = records.reduce(
    (a, r) => ({
      pay: a.pay + num(r.to_pay),
      receive: a.receive + num(r.to_receive),
      received: a.received + num(r.payment_received),
      invoices: a.invoices + r.invoices_sent,
    }),
    { pay: 0, receive: 0, received: 0, invoices: 0 },
  );

  doc.setFontSize(18);
  doc.text("Cyber Tools Store — Records", 40, 40);
  doc.setFontSize(10);
  doc.setTextColor(120);
  doc.text(`Generated ${today} · ${records.length} records`, 40, 58);
  doc.text(
    `You owe: ${fmt(totals.pay)}   Owed to you: ${fmt(totals.receive)}   Received: ${fmt(totals.received)}   Invoices sent: ${totals.invoices}`,
    40, 74,
  );
  doc.setTextColor(0);

  autoTable(doc, {
    startY: 90,
    head: [["Name", "Mobile", "Tool", "Account", "Method", "You owe", "Owed to you", "Inv.", "Received", "Status", "Reminder"]],
    body: records.map((r) => [
      r.name,
      r.mobile ?? "—",
      r.tool ?? "—",
      r.account ?? "—",
      r.payment_method ?? "—",
      fmt(num(r.to_pay)),
      fmt(num(r.to_receive)),
      String(r.invoices_sent),
      fmt(num(r.payment_received)),
      (r.payment_status ?? "unpaid").toUpperCase(),
      r.reminder_date ? `${r.reminder_date}${r.reminder_note ? " — " + r.reminder_note : ""}` : "—",
    ]),
    styles: { fontSize: 9, cellPadding: 5 },
    headStyles: { fillColor: [30, 41, 59], textColor: 255 },
    alternateRowStyles: { fillColor: [248, 246, 240] },
    columnStyles: {
      5: { halign: "right" }, 6: { halign: "right" },
      7: { halign: "right" }, 8: { halign: "right" },
    },
    didParseCell: (data) => {
      if (data.section === "body" && data.column.index === 9) {
        const v = String(data.cell.raw).toLowerCase();
        if (v === "paid") data.cell.styles.textColor = [22, 163, 74];
        else if (v === "partial") data.cell.styles.textColor = [180, 120, 20];
        else if (v === "unpaid") data.cell.styles.textColor = [220, 38, 38];
      }
    },
  });

  doc.save(`records-${new Date().toISOString().slice(0, 10)}.pdf`);
}
