import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) {
    navigate({ to: "/dashboard" });
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/dashboard` },
        });
        if (error) throw error;
        toast.success("Account created. Check your email to confirm.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      }
    } catch (err: any) {
      toast.error(err.message ?? "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin + "/dashboard",
    });
    if (result.error) {
      toast.error("Google sign-in failed");
      setBusy(false);
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/dashboard" });
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[oklch(0.18_0.03_255)] px-4 py-12 text-[oklch(0.95_0.012_85)]">
      <div className="pointer-events-none absolute -left-32 top-1/4 h-[460px] w-[460px] rounded-full bg-[oklch(0.72_0.13_70)]/20 blur-3xl" />
      <div className="pointer-events-none absolute -right-32 bottom-1/4 h-[460px] w-[460px] rounded-full bg-[oklch(0.55_0.18_280)]/20 blur-3xl" />

      <div className="relative w-full max-w-md">
        <Link to="/" className="mb-8 flex flex-col items-center justify-center gap-2">
          <img src={logo} alt="Cyber Tools Store" className="h-12 w-12 rounded-xl object-cover ring-1 ring-white/10" />
          <span className="font-display text-xl font-bold tracking-tight">Cyber Tools Store</span>
          <span className="text-xs text-white/50">Secure System Access</span>
        </Link>

        <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-8 backdrop-blur-xl">
          <h1 className="text-center font-display text-2xl font-bold">
            {mode === "signin" ? "Welcome Back" : "Create your account"}
          </h1>
          <p className="mt-1 text-center text-sm text-white/55">
            {mode === "signin" ? "Sign in with your member credentials." : "Start your 2-day free trial."}
          </p>

          <Button
            type="button"
            variant="outline"
            onClick={google}
            disabled={busy}
            className="mt-6 w-full border-white/15 bg-white/5 text-white hover:bg-white/10"
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
          </Button>

          <div className="my-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-white/10" />
            <span className="font-mono text-xs uppercase tracking-wider text-white/40">or</span>
            <div className="h-px flex-1 bg-white/10" />
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-white/80">Email Address</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 border-white/10 bg-white/5 text-white placeholder:text-white/30" placeholder="you@email.com" />
            </div>
            <div>
              <Label htmlFor="password" className="text-white/80">Password</Label>
              <Input id="password" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 border-white/10 bg-white/5 text-white placeholder:text-white/30" placeholder="••••••••" />
            </div>
            <Button type="submit" disabled={busy} className="w-full bg-white text-black hover:bg-white/90">
              {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {mode === "signin" ? "Secure Login" : "Create account"}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-white/55">
            {mode === "signin" ? "New here?" : "Already have an account?"}{" "}
            <button
              type="button"
              onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
              className="font-medium text-white underline-offset-4 hover:underline"
            >
              {mode === "signin" ? "Start free trial" : "Sign in"}
            </button>
          </p>
        </div>

        <p className="mt-4 text-center text-[11px] text-white/40">Protected by 256-bit AES encryption.</p>
      </div>
    </div>
  );
}
