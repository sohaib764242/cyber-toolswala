import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import {
  ShieldCheck,
  Zap,
  Lock,
  Globe,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Activity,
} from "lucide-react";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cyber Tools Store — Premium AI & Creator Tools" },
      {
        name: "description",
        content:
          "Get instant access to ChatGPT, Gemini, CapCut Pro, Veo 3 Ultra, HeyGen, Grok, VPNs and more — at one low monthly price. 2-day free trial.",
      },
    ],
  }),
  component: Landing,
});

const TOOLS = [
  { name: "ChatGPT", tag: "AI Chat" },
  { name: "Gemini", tag: "AI Suite" },
  { name: "Grok", tag: "AI Chat" },
  { name: "CapCut Pro", tag: "Video" },
  { name: "Veo 3 Ultra", tag: "Video AI" },
  { name: "HeyGen", tag: "Avatars" },
  { name: "Premium VPNs", tag: "Privacy" },
];

function Landing() {
  const { user, loading } = useAuth();
  if (!loading && user) return <Navigate to="/dashboard" />;

  return (
    <div className="relative min-h-screen overflow-hidden bg-[oklch(0.18_0.03_255)] text-[oklch(0.95_0.012_85)]">
      {/* Ambient orbs */}
      <div className="pointer-events-none absolute -left-40 top-20 h-[520px] w-[520px] rounded-full bg-[oklch(0.72_0.13_70)]/20 blur-3xl" />
      <div className="pointer-events-none absolute -right-32 top-1/3 h-[420px] w-[420px] rounded-full bg-[oklch(0.55_0.18_280)]/25 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 left-1/3 h-[380px] w-[380px] rounded-full bg-[oklch(0.58_0.13_155)]/15 blur-3xl" />

      {/* Nav */}
      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Link to="/" className="flex items-center gap-2.5">
          <img src={logo} alt="Cyber Tools Store" className="h-9 w-9 rounded-lg object-cover ring-1 ring-white/10" />
          <span className="font-display text-lg font-bold tracking-tight">Cyber Tools Store</span>
        </Link>
        <nav className="hidden items-center gap-7 text-sm text-white/70 md:flex">
          <a href="#tools" className="hover:text-white">Tools</a>
          <a href="#features" className="hover:text-white">Features</a>
          <a href="#pricing" className="hover:text-white">Pricing</a>
        </nav>
        <Link
          to="/login"
          className="rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm font-medium backdrop-blur hover:bg-white/10"
        >
          Sign in
        </Link>
      </header>

      {/* Hero */}
      <main className="relative z-10 mx-auto max-w-7xl px-6 pt-10 pb-20 md:pt-16">
        <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70 backdrop-blur">
              <Sparkles className="h-3.5 w-3.5 text-[oklch(0.72_0.13_70)]" />
              All your premium tools, one membership
            </div>
            <h1 className="mt-5 font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
              Unlock the world&rsquo;s best{" "}
              <span className="bg-gradient-to-r from-[oklch(0.72_0.13_70)] via-[oklch(0.78_0.15_75)] to-[oklch(0.85_0.12_85)] bg-clip-text text-transparent">
                AI & creator tools
              </span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-white/65">
              ChatGPT, Gemini, Grok, CapCut Pro, Veo 3 Ultra, HeyGen, premium
              VPNs and more — instantly. Start a 2-day free trial, then just
              $5/month.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/login"
                className="group inline-flex items-center gap-2 rounded-lg bg-white px-6 py-3 text-sm font-semibold text-black shadow-[0_0_40px_-10px_oklch(0.72_0.13_70)] transition hover:scale-[1.02]"
              >
                Start 2-day free trial
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
              </Link>
              <a
                href="#tools"
                className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-medium backdrop-blur hover:bg-white/10"
              >
                Browse tools
              </a>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-white/55">
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-[oklch(0.65_0.13_155)]" /> No commitment</span>
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-[oklch(0.65_0.13_155)]" /> Cancel anytime</span>
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-[oklch(0.65_0.13_155)]" /> Instant activation</span>
            </div>
          </div>

          {/* Glass sign-in card */}
          <div className="relative">
            <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-[oklch(0.72_0.13_70)]/30 to-[oklch(0.55_0.18_280)]/30 blur-2xl" />
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-7 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <img src={logo} alt="" className="h-11 w-11 rounded-xl object-cover ring-1 ring-white/15" />
                <div>
                  <p className="font-display text-lg font-bold">Member access</p>
                  <p className="text-xs text-white/55">Secure portal · AES-256</p>
                </div>
                <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-[oklch(0.65_0.13_155)]/15 px-2 py-0.5 text-[10px] font-medium text-[oklch(0.78_0.15_155)]">
                  <Activity className="h-2.5 w-2.5" /> Online
                </span>
              </div>

              <div className="mt-6 space-y-3">
                {[
                  { label: "ChatGPT Plus", status: "Active" },
                  { label: "CapCut Pro", status: "Active" },
                  { label: "Veo 3 Ultra", status: "Active" },
                  { label: "Premium VPN", status: "Active" },
                ].map((row) => (
                  <div
                    key={row.label}
                    className="flex items-center justify-between rounded-lg border border-white/5 bg-white/[0.03] px-4 py-3 text-sm"
                  >
                    <span className="text-white/85">{row.label}</span>
                    <span className="inline-flex items-center gap-1.5 text-xs text-[oklch(0.78_0.15_155)]">
                      <span className="h-1.5 w-1.5 rounded-full bg-[oklch(0.65_0.13_155)]" />
                      {row.status}
                    </span>
                  </div>
                ))}
              </div>

              <Link
                to="/login"
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-white py-3 text-sm font-semibold text-black hover:opacity-90"
              >
                <Lock className="h-4 w-4" /> Sign in to your account
              </Link>
              <p className="mt-3 text-center text-[11px] text-white/45">
                Protected by 256-bit AES encryption
              </p>
            </div>
          </div>
        </div>

        {/* Tools strip */}
        <section id="tools" className="mt-24">
          <div className="flex items-end justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.25em] text-white/45">Library</p>
              <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Tools included</h2>
            </div>
            <p className="hidden text-sm text-white/55 md:block">All in one membership · No extra fees</p>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {TOOLS.map((t) => (
              <div
                key={t.name}
                className="group relative overflow-hidden rounded-xl border border-white/10 bg-white/[0.03] p-5 transition hover:border-white/20 hover:bg-white/[0.06]"
              >
                <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-[oklch(0.72_0.13_70)]/15 blur-2xl transition group-hover:bg-[oklch(0.72_0.13_70)]/30" />
                <p className="font-display text-lg font-semibold">{t.name}</p>
                <p className="mt-1 text-xs uppercase tracking-wider text-white/50">{t.tag}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Features */}
        <section id="features" className="mt-24 grid gap-5 md:grid-cols-3">
          {[
            { icon: Zap, title: "Instant access", body: "Activate within minutes — log in and start using premium tools right away." },
            { icon: ShieldCheck, title: "Safe & private", body: "Encrypted accounts, secure delivery, zero shady workarounds." },
            { icon: Globe, title: "Works worldwide", body: "Use from anywhere. Backed by premium VPN access included in your plan." },
          ].map(({ icon: Icon, title, body }) => (
            <div key={title} className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[oklch(0.72_0.13_70)]/15 text-[oklch(0.78_0.15_75)]">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{title}</h3>
              <p className="mt-1 text-sm text-white/60">{body}</p>
            </div>
          ))}
        </section>

        {/* Pricing */}
        <section id="pricing" className="mt-24">
          <div className="mx-auto max-w-2xl text-center">
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-white/45">Pricing</p>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">One plan. Everything included.</h2>
            <p className="mt-3 text-white/60">Try it free for 2 days. Then $5/month — cancel anytime.</p>
          </div>

          <div className="mx-auto mt-10 max-w-md">
            <div className="relative rounded-2xl border border-white/15 bg-gradient-to-br from-white/[0.07] to-white/[0.02] p-8 backdrop-blur-xl">
              <div className="absolute -inset-px -z-10 rounded-2xl bg-gradient-to-br from-[oklch(0.72_0.13_70)]/40 to-[oklch(0.55_0.18_280)]/40 blur-xl" />
              <p className="text-sm font-medium text-[oklch(0.78_0.15_75)]">Member · Monthly</p>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="font-display text-6xl font-bold">$5</span>
                <span className="text-white/55">/month</span>
              </div>
              <p className="mt-2 text-sm text-white/60">Starts after your 2-day free trial</p>

              <ul className="mt-6 space-y-2.5 text-sm">
                {[
                  "Access to all tools in the library",
                  "ChatGPT, Gemini, Grok included",
                  "CapCut Pro, Veo 3 Ultra, HeyGen",
                  "Premium VPN access",
                  "Priority support",
                ].map((f) => (
                  <li key={f} className="flex items-start gap-2 text-white/80">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[oklch(0.65_0.13_155)]" />
                    {f}
                  </li>
                ))}
              </ul>

              <Link
                to="/login"
                className="mt-7 flex w-full items-center justify-center gap-2 rounded-lg bg-white py-3 text-sm font-semibold text-black hover:opacity-90"
              >
                Start 2-day free trial <ArrowRight className="h-4 w-4" />
              </Link>
              <p className="mt-3 text-center text-[11px] text-white/45">
                Card payments coming soon · placeholder account details on file
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-white/10 py-8 text-center text-xs text-white/45">
        © {new Date().getFullYear()} Cyber Tools Store · Premium tools, one membership.
      </footer>
    </div>
  );
}
