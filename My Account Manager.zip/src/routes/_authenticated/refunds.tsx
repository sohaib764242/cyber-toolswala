import { createFileRoute } from "@tanstack/react-router";
import { Undo2 } from "lucide-react";
import { PageHeader, Card, StatCard, StatusPill, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/refunds")({ component: RefundsPage });

const REFUNDS = [
  { id: "RFD-088", client: "Usman Tariq", reason: "Service not delivered", amount: 5500, status: "processed", date: "2026-05-05" },
  { id: "RFD-087", client: "Hina Raza", reason: "Duplicate charge", amount: 1200, status: "processing", date: "2026-05-04" },
  { id: "RFD-086", client: "Ahmed Khan", reason: "Account issue", amount: 2500, status: "processed", date: "2026-05-02" },
  { id: "RFD-085", client: "Sara Ali", reason: "Customer request", amount: 1500, status: "rejected", date: "2026-04-29" },
];

function RefundsPage() {
  const total = REFUNDS.filter(r => r.status === "processed").reduce((s, r) => s + r.amount, 0);

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Customer Refunds" subtitle="Track and process refund requests" icon={Undo2} />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Total refunded" value={fmtRs(total)} tone="danger" icon={Undo2} />
        <StatCard label="Processing" value="1" tone="accent" icon={Undo2} />
        <StatCard label="This month" value={fmtRs(9200)} icon={Undo2} />
      </div>

      <Card className="mt-5">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 text-left text-[10px] uppercase tracking-wider text-white/45">
                <th className="pb-3 pr-4">Refund ID</th>
                <th className="pb-3 pr-4">Client</th>
                <th className="pb-3 pr-4">Reason</th>
                <th className="pb-3 pr-4">Amount</th>
                <th className="pb-3 pr-4">Date</th>
                <th className="pb-3 pr-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {REFUNDS.map((r) => (
                <tr key={r.id}>
                  <td className="py-3 pr-4 font-mono text-xs text-white/70">{r.id}</td>
                  <td className="py-3 pr-4 font-medium">{r.client}</td>
                  <td className="py-3 pr-4 text-white/55">{r.reason}</td>
                  <td className="py-3 pr-4 font-mono font-semibold">{fmtRs(r.amount)}</td>
                  <td className="py-3 pr-4 font-mono text-xs text-white/55">{r.date}</td>
                  <td className="py-3 pr-4"><StatusPill label={r.status}
                    tone={r.status === "processed" ? "success" : r.status === "processing" ? "warning" : "danger"} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
