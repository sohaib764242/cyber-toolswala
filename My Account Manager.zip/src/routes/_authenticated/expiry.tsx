import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, Bell } from "lucide-react";
import { PageHeader, Card, StatCard } from "@/components/section";

export const Route = createFileRoute("/_authenticated/expiry")({ component: ExpiryPage });

const ALERTS = [
  { client: "Ahmed Khan", product: "ChatGPT Plus", expires: "2026-05-12", days: 2 },
  { client: "Sara Ali", product: "CapCut Pro", expires: "2026-05-13", days: 3 },
  { client: "Bilal Hassan", product: "Veo 3 Ultra", expires: "2026-05-15", days: 5 },
  { client: "Hina Raza", product: "Premium VPN", expires: "2026-05-18", days: 8 },
  { client: "Omar Faruq", product: "HeyGen Pro", expires: "2026-05-20", days: 10 },
];

function ExpiryPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Expiry Alerts" subtitle="Subscriptions ending soon — reach out before they lapse" icon={AlertTriangle} />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Expiring in 7 days" value="3" tone="danger" icon={AlertTriangle} />
        <StatCard label="Expiring in 30 days" value="12" tone="accent" icon={Bell} />
        <StatCard label="Total active subs" value="184" icon={Bell} />
      </div>

      <Card className="mt-5">
        <h2 className="font-display text-lg font-semibold">Upcoming expirations</h2>
        <ul className="mt-4 divide-y divide-white/5">
          {ALERTS.map((a, i) => {
            const tone = a.days <= 3 ? "danger" : a.days <= 7 ? "warning" : "info";
            const toneStyle = tone === "danger" ? "bg-[oklch(0.65_0.21_27)]/15 text-[oklch(0.78_0.21_27)] border-[oklch(0.65_0.21_27)]/30"
              : tone === "warning" ? "bg-[oklch(0.78_0.15_75)]/15 text-[oklch(0.85_0.15_75)] border-[oklch(0.78_0.15_75)]/30"
              : "bg-[oklch(0.55_0.18_280)]/15 text-[oklch(0.78_0.15_280)] border-[oklch(0.55_0.18_280)]/30";
            return (
              <li key={i} className="flex items-center justify-between gap-4 py-3">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <div className={`rounded-lg border px-2.5 py-1.5 text-xs font-mono ${toneStyle}`}>{a.days}d</div>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{a.client}</p>
                    <p className="truncate text-[11px] text-white/45">{a.product} · expires {a.expires}</p>
                  </div>
                </div>
                <button className="rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-xs hover:bg-white/10">Notify</button>
              </li>
            );
          })}
        </ul>
      </Card>
    </div>
  );
}
