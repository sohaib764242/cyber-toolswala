import { createFileRoute } from "@tanstack/react-router";
import { ShoppingCart, Search, Filter } from "lucide-react";
import { PageHeader, Card, StatusPill, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/orders")({ component: OrdersPage });

const ORDERS = [
  { id: "ORD-1042", client: "Ahmed Khan", product: "ChatGPT Plus · 1 mo", amount: 2500, status: "paid", date: "2026-05-10" },
  { id: "ORD-1041", client: "Sara Ali", product: "CapCut Pro · 3 mo", amount: 4500, status: "paid", date: "2026-05-10" },
  { id: "ORD-1040", client: "Bilal Hassan", product: "Veo 3 Ultra · 1 mo", amount: 6000, status: "pending", date: "2026-05-09" },
  { id: "ORD-1039", client: "Hina Raza", product: "Premium VPN · 1 yr", amount: 3200, status: "paid", date: "2026-05-09" },
  { id: "ORD-1038", client: "Usman Tariq", product: "HeyGen Pro · 1 mo", amount: 5500, status: "overdue", date: "2026-05-07" },
  { id: "ORD-1037", client: "Nadia Sheikh", product: "Gemini Advanced", amount: 2800, status: "paid", date: "2026-05-07" },
  { id: "ORD-1036", client: "Omar Faruq", product: "Grok Premium", amount: 3800, status: "pending", date: "2026-05-06" },
];

function OrdersPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader
        title="Orders"
        subtitle="All customer orders and payment status"
        icon={ShoppingCart}
        actions={
          <button className="rounded-lg bg-white px-3 py-2 text-sm font-semibold text-black hover:bg-white/90">+ New order</button>
        }
      />

      <Card>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
            <input placeholder="Search orders, clients, products..." className="w-full rounded-lg border border-white/10 bg-white/5 py-2 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-white/30 focus:outline-none" />
          </div>
          <button className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white/80 hover:bg-white/10">
            <Filter className="h-4 w-4" /> All status
          </button>
        </div>

        <div className="mt-5 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 text-left text-[10px] uppercase tracking-wider text-white/45">
                <th className="pb-3 pr-4 font-medium">Order ID</th>
                <th className="pb-3 pr-4 font-medium">Client</th>
                <th className="pb-3 pr-4 font-medium">Product</th>
                <th className="pb-3 pr-4 font-medium">Date</th>
                <th className="pb-3 pr-4 font-medium">Amount</th>
                <th className="pb-3 pr-4 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ORDERS.map((o) => (
                <tr key={o.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 pr-4 font-mono text-xs text-white/70">{o.id}</td>
                  <td className="py-3 pr-4">{o.client}</td>
                  <td className="py-3 pr-4 text-white/70">{o.product}</td>
                  <td className="py-3 pr-4 font-mono text-xs text-white/50">{o.date}</td>
                  <td className="py-3 pr-4 font-mono font-semibold">{fmtRs(o.amount)}</td>
                  <td className="py-3 pr-4">
                    <StatusPill label={o.status} tone={o.status === "paid" ? "success" : o.status === "pending" ? "warning" : "danger"} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
