import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/invoices")({ component: InvoicesPage });

type Status = "draft" | "sent" | "paid" | "overdue";

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);

const statusStyles: Record<Status, string> = {
  paid: "bg-success/15 text-success",
  sent: "bg-accent/20 text-accent-foreground",
  overdue: "bg-destructive/15 text-destructive",
  draft: "bg-muted text-muted-foreground",
};

type FormState = {
  invoice_number: string;
  client_id: string;
  amount: string;
  status: Status;
  issue_date: string;
  due_date: string;
  notes: string;
};

const today = () => new Date().toISOString().slice(0, 10);
const empty = (): FormState => ({
  invoice_number: "",
  client_id: "",
  amount: "",
  status: "draft",
  issue_date: today(),
  due_date: "",
  notes: "",
});

function InvoicesPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FormState>(empty());

  const { data: clients = [] } = useQuery({
    queryKey: ["clients", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("clients").select("id,name").order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ["invoices", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("invoices").select("*").order("issue_date", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const clientMap = new Map(clients.map((c) => [c.id, c.name]));

  const create = useMutation({
    mutationFn: async () => {
      if (!form.invoice_number.trim()) throw new Error("Invoice number required");
      const amt = Number(form.amount);
      if (isNaN(amt) || amt < 0) throw new Error("Valid amount required");
      const { error } = await supabase.from("invoices").insert({
        user_id: user!.id,
        invoice_number: form.invoice_number.trim(),
        client_id: form.client_id || null,
        amount: amt,
        status: form.status,
        issue_date: form.issue_date,
        due_date: form.due_date || null,
        notes: form.notes.trim() || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Invoice added");
      setForm(empty());
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["invoices"] });
      qc.invalidateQueries({ queryKey: ["dash"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: Status }) => {
      const { error } = await supabase.from("invoices").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["invoices"] });
      qc.invalidateQueries({ queryKey: ["dash"] });
    },
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("invoices").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Removed");
      qc.invalidateQueries({ queryKey: ["invoices"] });
      qc.invalidateQueries({ queryKey: ["dash"] });
    },
  });

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">Folio · Ledger</p>
          <h1 className="mt-1 text-3xl font-bold md:text-4xl">Invoices</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> New invoice</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New invoice</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Invoice # *">
                  <Input placeholder="INV-0001" value={form.invoice_number} onChange={(e) => setForm({ ...form, invoice_number: e.target.value })} />
                </Field>
                <Field label="Amount *">
                  <Input type="number" step="0.01" min="0" placeholder="0.00" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                </Field>
              </div>
              <Field label="Client">
                <Select value={form.client_id} onValueChange={(v) => setForm({ ...form, client_id: v })}>
                  <SelectTrigger><SelectValue placeholder={clients.length ? "Select client" : "No clients yet — add one first"} /></SelectTrigger>
                  <SelectContent>
                    {clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Issue date"><Input type="date" value={form.issue_date} onChange={(e) => setForm({ ...form, issue_date: e.target.value })} /></Field>
                <Field label="Due date"><Input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} /></Field>
              </div>
              <Field label="Status">
                <Select value={form.status} onValueChange={(v: Status) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(["draft", "sent", "paid", "overdue"] as Status[]).map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Notes"><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => create.mutate()} disabled={create.isPending}>Save invoice</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="ledger-card mt-8 overflow-hidden rounded-lg">
        {isLoading ? (
          <p className="p-6 text-sm text-muted-foreground">Loading…</p>
        ) : invoices.length === 0 ? (
          <div className="p-12 text-center">
            <p className="font-display text-lg font-semibold">No entries yet</p>
            <p className="mt-1 text-sm text-muted-foreground">Add your first invoice above.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Invoice</th>
                  <th className="px-4 py-3 text-left">Client</th>
                  <th className="px-4 py-3 text-left">Issued</th>
                  <th className="px-4 py-3 text-left">Due</th>
                  <th className="px-4 py-3 text-right">Amount</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {invoices.map((i) => (
                  <tr key={i.id} className="hover:bg-muted/30">
                    <td className="px-4 py-3 font-mono">{i.invoice_number}</td>
                    <td className="px-4 py-3">{i.client_id ? clientMap.get(i.client_id) ?? "—" : "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{i.issue_date}</td>
                    <td className="px-4 py-3 text-muted-foreground">{i.due_date ?? "—"}</td>
                    <td className="px-4 py-3 text-right font-mono font-semibold">{fmt(Number(i.amount))}</td>
                    <td className="px-4 py-3">
                      <Select
                        value={i.status}
                        onValueChange={(v: Status) => updateStatus.mutate({ id: i.id, status: v })}
                      >
                        <SelectTrigger className={`h-7 w-28 border-0 px-2 text-xs uppercase tracking-wider ${statusStyles[i.status as Status]}`}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {(["draft", "sent", "paid", "overdue"] as Status[]).map((s) => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => { if (confirm(`Remove ${i.invoice_number}?`)) remove.mutate(i.id); }}
                        className="rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label className="mb-1 block">{label}</Label>
      {children}
    </div>
  );
}
