import { createFileRoute } from "@tanstack/react-router";
import { CreditCard } from "lucide-react";
import { PageHeader, Card, StatCard, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/pending-payments")({ component: PendingPaymentsPage });

const PENDING = [
  { client: "Bilal Hassan", invoice: "INV-1040", amount: 6000, due: "2026-05-12", days: 2 },
  { client: "Omar Faruq", invoice: "INV-1036", amount: 3800, due: "2026-05-13", days: 3 },
  { client: "Usman Tariq", invoice: "INV-1038", amount: 5500, due: "2026-05-07", days: -3 },
];

function PendingPaymentsPage() {
  const total = PENDING.reduce((s, p) => s + p.amount, 0);
  const overdue = PENDING.filter((p) => p.days < 0).reduce((s, p) => s + p.amount, 0);

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Pending Payments" subtitle="Outstanding balances awaiting collection" icon={CreditCard} />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Total pending" value={fmtRs(total)} tone="accent" icon={CreditCard} />
        <StatCard label="Overdue" value={fmtRs(overdue)} tone="danger" icon={CreditCard} />
        <StatCard label="Pending invoices" value={`${PENDING.length}`} icon={CreditCard} />
      </div>

      <Card className="mt-5">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 text-left text-[10px] uppercase tracking-wider text-white/45">
                <th className="pb-3 pr-4">Client</th>
                <th className="pb-3 pr-4">Invoice</th>
                <th className="pb-3 pr-4">Amount</th>
                <th className="pb-3 pr-4">Due</th>
                <th className="pb-3 pr-4">Status</th>
                <th className="pb-3 pr-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {PENDING.map((p) => (
                <tr key={p.invoice}>
                  <td className="py-3 pr-4 font-medium">{p.client}</td>
                  <td className="py-3 pr-4 font-mono text-xs text-white/70">{p.invoice}</td>
                  <td className="py-3 pr-4 font-mono font-semibold">{fmtRs(p.amount)}</td>
                  <td className="py-3 pr-4 font-mono text-xs text-white/55">{p.due}</td>
                  <td className="py-3 pr-4">
                    <span className={`text-xs font-medium ${p.days < 0 ? "text-[oklch(0.78_0.21_27)]" : "text-[oklch(0.85_0.15_75)]"}`}>
                      {p.days < 0 ? `${Math.abs(p.days)}d overdue` : `Due in ${p.days}d`}
                    </span>
                  </td>
                  <td className="py-3 pr-4 text-right">
                    <button className="rounded-md bg-white px-3 py-1.5 text-xs font-semibold text-black hover:bg-white/90">Mark paid</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
