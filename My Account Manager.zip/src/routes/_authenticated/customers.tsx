import { createFileRoute } from "@tanstack/react-router";
import { Users, Search, Phone, Mail } from "lucide-react";
import { PageHeader, Card, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/customers")({ component: CustomersPage });

const CUSTOMERS = [
  { name: "Ahmed Khan", phone: "+923001234567", email: "ahmed@email.com", orders: 22, ltv: 78500 },
  { name: "Sara Ali", phone: "+923002345678", email: "sara@email.com", orders: 18, ltv: 64200 },
  { name: "Bilal Hassan", phone: "+923003456789", email: "bilal@email.com", orders: 12, ltv: 48000 },
  { name: "Hina Raza", phone: "+923004567890", email: "hina@email.com", orders: 9, ltv: 32400 },
  { name: "Usman Tariq", phone: "+923005678901", email: "usman@email.com", orders: 7, ltv: 25800 },
  { name: "Nadia Sheikh", phone: "+923006789012", email: "nadia@email.com", orders: 5, ltv: 18500 },
];

function CustomersPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Customers" subtitle="All your registered clients" icon={Users}
        actions={<button className="rounded-lg bg-white px-3 py-2 text-sm font-semibold text-black">+ Add customer</button>} />

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
        <input placeholder="Search customers..." className="w-full rounded-lg border border-white/10 bg-white/5 py-2.5 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-white/30 focus:outline-none" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {CUSTOMERS.map((c) => (
          <Card key={c.name}>
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-sm font-semibold uppercase">{c.name.split(" ").map(s => s[0]).join("").slice(0,2)}</div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-display font-bold">{c.name}</p>
                <p className="truncate text-xs text-white/45">{c.email}</p>
              </div>
            </div>
            <div className="mt-3 space-y-1.5 text-xs text-white/55">
              <p className="flex items-center gap-2"><Phone className="h-3 w-3" /> {c.phone}</p>
              <p className="flex items-center gap-2"><Mail className="h-3 w-3" /> {c.email}</p>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 rounded-lg border border-white/10 bg-white/[0.02] p-3 text-center">
              <div>
                <p className="font-mono text-base font-bold">{c.orders}</p>
                <p className="text-[10px] uppercase tracking-wider text-white/45">Orders</p>
              </div>
              <div>
                <p className="font-mono text-base font-bold text-[oklch(0.85_0.15_75)]">{fmtRs(c.ltv)}</p>
                <p className="text-[10px] uppercase tracking-wider text-white/45">Lifetime</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
