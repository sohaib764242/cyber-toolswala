import { createFileRoute } from "@tanstack/react-router";
import { BarChart3, TrendingUp, TrendingDown, Activity } from "lucide-react";
import { PageHeader, Card, StatCard, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/analytics")({ component: AnalyticsPage });

const TOP_PRODUCTS = [
  { name: "ChatGPT Plus", units: 68, revenue: 170000, change: 12 },
  { name: "CapCut Pro", units: 52, revenue: 156000, change: 8 },
  { name: "Premium VPN", units: 41, revenue: 123000, change: -3 },
  { name: "Veo 3 Ultra", units: 28, revenue: 168000, change: 22 },
  { name: "HeyGen Pro", units: 19, revenue: 104500, change: 5 },
  { name: "Gemini Advanced", units: 35, revenue: 87500, change: 14 },
];

function AnalyticsPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Analytics" subtitle="Performance insights across your store" icon={BarChart3} />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Conversion Rate" value="24.6%" hint="↑ 3.2% vs last month" tone="success" icon={Activity} />
        <StatCard label="Avg Order Value" value={fmtRs(3398)} hint="↑ Rs. 240 vs last month" tone="success" icon={TrendingUp} />
        <StatCard label="Refund Rate" value="2.1%" hint="↓ 0.4% vs last month" tone="success" icon={TrendingDown} />
        <StatCard label="Active Customers" value="184" hint="62 new this month" tone="accent" icon={Activity} />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h2 className="font-display text-lg font-semibold">Top Products by Revenue</h2>
          <p className="text-xs text-white/45">Last 30 days</p>
          <div className="mt-5 space-y-4">
            {TOP_PRODUCTS.map((p) => {
              const pct = Math.round((p.revenue / 170000) * 100);
              return (
                <div key={p.name}>
                  <div className="mb-1.5 flex items-center justify-between text-sm">
                    <span className="font-medium">{p.name}</span>
                    <span className="font-mono text-white/70">{fmtRs(p.revenue)}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/5">
                      <div className="h-full rounded-full bg-gradient-to-r from-[oklch(0.78_0.15_75)] to-[oklch(0.85_0.15_85)]" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="w-12 text-right text-[11px] text-white/45">{p.units} sold</span>
                    <span className={`w-10 text-right text-[11px] ${p.change > 0 ? "text-[oklch(0.78_0.15_155)]" : "text-[oklch(0.78_0.21_27)]"}`}>
                      {p.change > 0 ? "+" : ""}{p.change}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-lg font-semibold">Customer Distribution</h2>
          <p className="text-xs text-white/45">By order frequency</p>
          <div className="mt-6 flex flex-col items-center">
            <div className="relative flex h-44 w-44 items-center justify-center">
              <div className="absolute inset-0 rounded-full" style={{ background: "conic-gradient(oklch(0.78 0.15 75) 0 45%, oklch(0.65 0.13 155) 45% 75%, oklch(0.55 0.18 280) 75% 100%)" }} />
              <div className="relative h-28 w-28 rounded-full bg-[oklch(0.16_0.025_255)] flex flex-col items-center justify-center">
                <p className="font-mono text-xl font-bold">184</p>
                <p className="text-[10px] uppercase tracking-wider text-white/45">Total</p>
              </div>
            </div>
            <div className="mt-5 w-full space-y-2 text-sm">
              <div className="flex items-center justify-between"><span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-sm bg-[oklch(0.78_0.15_75)]" /> Repeat buyers</span><span className="font-mono text-white/70">83</span></div>
              <div className="flex items-center justify-between"><span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-sm bg-[oklch(0.65_0.13_155)]" /> Regular</span><span className="font-mono text-white/70">55</span></div>
              <div className="flex items-center justify-between"><span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-sm bg-[oklch(0.55_0.18_280)]" /> New</span><span className="font-mono text-white/70">46</span></div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
