import { createFileRoute } from "@tanstack/react-router";
import { History } from "lucide-react";
import { PageHeader, Card, StatusPill, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/sales-history")({ component: SalesHistoryPage });

const SALES = [
  { date: "2026-05-10", count: 6, total: 24500, items: [
    { time: "14:22", client: "Ahmed Khan", product: "ChatGPT Plus", amt: 2500, status: "paid" },
    { time: "11:08", client: "Sara Ali", product: "CapCut Pro · 3 mo", amt: 4500, status: "paid" },
  ]},
  { date: "2026-05-09", count: 4, total: 18200, items: [
    { time: "16:45", client: "Bilal Hassan", product: "Veo 3 Ultra", amt: 6000, status: "pending" },
    { time: "09:30", client: "Hina Raza", product: "Premium VPN · 1 yr", amt: 3200, status: "paid" },
  ]},
  { date: "2026-05-07", count: 3, total: 12100, items: [
    { time: "13:10", client: "Usman Tariq", product: "HeyGen Pro", amt: 5500, status: "overdue" },
  ]},
];

function SalesHistoryPage() {
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Sales History" subtitle="Full chronological log of all transactions" icon={History} />

      <div className="space-y-5">
        {SALES.map((day) => (
          <div key={day.date}>
            <div className="mb-2 flex items-center justify-between px-1">
              <p className="font-mono text-xs uppercase tracking-wider text-white/55">{day.date}</p>
              <p className="text-xs text-white/45">{day.count} sales · <span className="font-mono text-white/70">{fmtRs(day.total)}</span></p>
            </div>
            <Card className="!p-0">
              <ul className="divide-y divide-white/5">
                {day.items.map((s, i) => (
                  <li key={i} className="flex items-center gap-4 px-5 py-3">
                    <span className="font-mono text-xs text-white/40">{s.time}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{s.client}</p>
                      <p className="truncate text-[11px] text-white/45">{s.product}</p>
                    </div>
                    <span className="font-mono text-sm font-semibold">{fmtRs(s.amt)}</span>
                    <StatusPill label={s.status} tone={s.status === "paid" ? "success" : s.status === "pending" ? "warning" : "danger"} />
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}
