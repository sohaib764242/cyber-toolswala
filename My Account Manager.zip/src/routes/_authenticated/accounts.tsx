import { createFileRoute } from "@tanstack/react-router";
import { Wallet, ArrowDownRight, ArrowUpRight } from "lucide-react";
import { PageHeader, Card, StatCard, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/accounts")({ component: AccountsPage });

const ACCOUNTS = [
  { name: "JazzCash Business", type: "Mobile wallet", balance: 142500, ref: "0300-XXXXXXX" },
  { name: "Easypaisa Merchant", type: "Mobile wallet", balance: 86200, ref: "0345-XXXXXXX" },
  { name: "Meezan Bank", type: "Bank account", balance: 312800, ref: "01-XXXX-XXXX-XX" },
];

const TRANSACTIONS = [
  { type: "in", desc: "Sale · ChatGPT Plus · Ahmed K", amt: 2500, when: "2h ago" },
  { type: "in", desc: "Sale · CapCut Pro · Sara A", amt: 4500, when: "5h ago" },
  { type: "out", desc: "Vendor payout · Work Easy Tool", amt: 12000, when: "Yesterday" },
  { type: "in", desc: "Sale · Premium VPN · Hina R", amt: 3200, when: "Yesterday" },
  { type: "out", desc: "Refund · Usman T", amt: 5500, when: "5d ago" },
];

function AccountsPage() {
  const total = ACCOUNTS.reduce((s, a) => s + a.balance, 0);

  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Payments & Accounts" subtitle="Account balances and transaction history" icon={Wallet} />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total balance" value={fmtRs(total)} tone="success" icon={Wallet} />
        <StatCard label="This week in" value={fmtRs(48200)} tone="success" icon={ArrowDownRight} />
        <StatCard label="This week out" value={fmtRs(17500)} tone="danger" icon={ArrowUpRight} />
        <StatCard label="Net flow" value={fmtRs(30700)} tone="accent" icon={Wallet} />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="mb-4 font-display text-lg font-semibold">Accounts</h2>
          <div className="space-y-3">
            {ACCOUNTS.map((a) => (
              <div key={a.name} className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-display font-bold">{a.name}</p>
                    <p className="text-[11px] text-white/45">{a.type} · <span className="font-mono">{a.ref}</span></p>
                  </div>
                  <p className="font-mono text-lg font-bold">{fmtRs(a.balance)}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="mb-4 font-display text-lg font-semibold">Recent transactions</h2>
          <ul className="divide-y divide-white/5">
            {TRANSACTIONS.map((t, i) => (
              <li key={i} className="flex items-center gap-3 py-3">
                <div className={`rounded-lg p-2 ${t.type === "in" ? "bg-[oklch(0.65_0.13_155)]/15 text-[oklch(0.78_0.15_155)]" : "bg-[oklch(0.65_0.21_27)]/15 text-[oklch(0.78_0.21_27)]"}`}>
                  {t.type === "in" ? <ArrowDownRight className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm">{t.desc}</p>
                  <p className="text-[11px] text-white/45">{t.when}</p>
                </div>
                <p className={`font-mono text-sm font-semibold ${t.type === "in" ? "text-[oklch(0.78_0.15_155)]" : "text-[oklch(0.78_0.21_27)]"}`}>
                  {t.type === "in" ? "+" : "−"}{fmtRs(t.amt)}
                </p>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
