import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PlusCircle, ArrowLeft, ArrowRight, Search, User, Package, CheckCircle2 } from "lucide-react";
import { PageHeader, Card, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/new-sale")({ component: NewSalePage });

const TOOLS = [
  { name: "ChatGPT Plus · 1 month", price: 2500 },
  { name: "ChatGPT Plus · 3 months", price: 7000 },
  { name: "CapCut Pro · 1 month", price: 1500 },
  { name: "CapCut Pro · 3 months", price: 4500 },
  { name: "Veo 3 Ultra · 1 month", price: 6000 },
  { name: "HeyGen Pro · 1 month", price: 5500 },
  { name: "Premium VPN · 1 year", price: 3200 },
  { name: "Gemini Advanced", price: 2800 },
  { name: "Grok Premium", price: 3800 },
];

function NewSalePage() {
  const [step, setStep] = useState(1);
  const [mode, setMode] = useState<"search" | "new">("search");
  const [selectedTool, setSelectedTool] = useState<typeof TOOLS[number] | null>(null);

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title="New Sale"
        subtitle={`Step ${step} of 3`}
        icon={PlusCircle}
        actions={
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70">STEP {step} OF 3</span>
        }
      />

      {/* Progress */}
      <div className="mb-5 flex gap-2">
        {[1, 2, 3].map((n) => (
          <div key={n} className={`h-1 flex-1 rounded-full ${n <= step ? "bg-white" : "bg-white/10"}`} />
        ))}
      </div>

      <Card>
        {step === 1 && (
          <div>
            <p className="mb-4 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-white/55">
              <User className="h-3.5 w-3.5" /> 1. Customer Details
            </p>

            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setMode("search")} className={`rounded-lg px-4 py-2.5 text-sm font-medium ${mode === "search" ? "bg-white text-black" : "border border-white/10 bg-white/5 text-white/70"}`}>
                Search database
              </button>
              <button onClick={() => setMode("new")} className={`rounded-lg px-4 py-2.5 text-sm font-medium ${mode === "new" ? "bg-white text-black" : "border border-white/10 bg-white/5 text-white/70"}`}>
                New customer
              </button>
            </div>

            {mode === "search" ? (
              <div className="relative mt-4">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
                <input placeholder="Type name, phone or email..." className="w-full rounded-lg border border-white/10 bg-white/5 py-2.5 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-white/30 focus:outline-none" />
              </div>
            ) : (
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <input placeholder="Full name" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white placeholder:text-white/40" />
                <input placeholder="Phone" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white placeholder:text-white/40" />
                <input placeholder="Email (optional)" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white placeholder:text-white/40 sm:col-span-2" />
              </div>
            )}

            <button onClick={() => setStep(2)} className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-white py-3 text-sm font-semibold text-black hover:bg-white/90">
              Next: Select product <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        )}

        {step === 2 && (
          <div>
            <p className="mb-4 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-white/55">
              <Package className="h-3.5 w-3.5" /> 2. Select product
            </p>
            <div className="grid gap-2 sm:grid-cols-2">
              {TOOLS.map((t) => (
                <button
                  key={t.name}
                  onClick={() => setSelectedTool(t)}
                  className={`flex items-center justify-between rounded-lg border px-4 py-3 text-left text-sm transition ${
                    selectedTool?.name === t.name
                      ? "border-[oklch(0.78_0.15_75)]/60 bg-[oklch(0.78_0.15_75)]/10"
                      : "border-white/10 bg-white/[0.02] hover:border-white/20"
                  }`}
                >
                  <span className="text-white/85">{t.name}</span>
                  <span className="font-mono font-semibold">{fmtRs(t.price)}</span>
                </button>
              ))}
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setStep(1)} className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white/80 hover:bg-white/10">
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <button onClick={() => selectedTool && setStep(3)} disabled={!selectedTool} className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-white py-3 text-sm font-semibold text-black hover:bg-white/90 disabled:opacity-40">
                Next: Confirm <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <p className="mb-4 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-white/55">
              <CheckCircle2 className="h-3.5 w-3.5" /> 3. Confirm sale
            </p>

            <div className="space-y-2 rounded-lg border border-white/10 bg-white/[0.02] p-4 text-sm">
              <div className="flex justify-between"><span className="text-white/55">Product</span><span>{selectedTool?.name}</span></div>
              <div className="flex justify-between"><span className="text-white/55">Subtotal</span><span className="font-mono">{fmtRs(selectedTool?.price ?? 0)}</span></div>
              <div className="flex justify-between border-t border-white/10 pt-2 text-base font-semibold"><span>Total</span><span className="font-mono">{fmtRs(selectedTool?.price ?? 0)}</span></div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setStep(2)} className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white/80 hover:bg-white/10">
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <button className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-[oklch(0.65_0.13_155)] py-3 text-sm font-semibold text-black hover:opacity-90">
                Complete sale <CheckCircle2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
