import { createFileRoute, Link } from "@tanstack/react-router";
import { Calendar, ShoppingCart, DollarSign, TrendingUp, Users, Building2, PlusCircle, Inbox } from "lucide-react";
import { StatCard, Card, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/dashboard")({ component: Dashboard });

function Dashboard() {
  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="mt-1 flex items-center gap-2 text-sm text-white/55">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-[oklch(0.65_0.13_155)]" />
            Welcome — your workspace is ready
          </p>
        </div>
        <div className="flex gap-2">
          <button className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white/80 hover:bg-white/10">
            <Calendar className="h-4 w-4" /> All time
          </button>
          <Link
            to="/new-sale"
            className="inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-sm font-medium text-black hover:bg-white/90"
          >
            <PlusCircle className="h-4 w-4" /> New Sale
          </Link>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Total Orders" value="0" hint="All time transactions" icon={ShoppingCart} />
        <StatCard label="Gross Revenue" value={fmtRs(0)} hint="No sales yet" icon={DollarSign} />
        <StatCard label="Net Profit" value={fmtRs(0)} hint="No profit yet" icon={TrendingUp} />
        <StatCard label="Customer Pending" value={fmtRs(0)} hint="Nothing pending" icon={Users} />
        <StatCard label="Vendor Dues" value={fmtRs(0)} hint="No dues" icon={Building2} />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-semibold">Revenue vs Profit</h2>
              <p className="text-xs text-white/45">Last 12 months</p>
            </div>
          </div>
          <div className="mt-10 flex h-48 flex-col items-center justify-center text-center">
            <Inbox className="h-10 w-10 text-white/20" />
            <p className="mt-3 text-sm text-white/55">No data yet</p>
            <p className="text-xs text-white/35">Record your first sale to see analytics here.</p>
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Recent Sales</h2>
          </div>
          <div className="flex h-48 flex-col items-center justify-center text-center">
            <ShoppingCart className="h-10 w-10 text-white/20" />
            <p className="mt-3 text-sm text-white/55">No sales yet</p>
            <Link to="/new-sale" className="mt-2 text-xs text-white/70 underline-offset-4 hover:underline">
              Add your first sale →
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
