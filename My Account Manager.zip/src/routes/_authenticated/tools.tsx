import { createFileRoute } from "@tanstack/react-router";
import { Package, Sparkles } from "lucide-react";
import { PageHeader, Card, fmtRs, StatusPill } from "@/components/section";

export const Route = createFileRoute("/_authenticated/tools")({ component: ToolsPage });

const TOOLS = [
  { name: "ChatGPT Plus", category: "AI Chat", stock: 14, price: 2500, status: "in-stock" },
  { name: "Gemini Advanced", category: "AI Suite", stock: 8, price: 2800, status: "in-stock" },
  { name: "Grok Premium", category: "AI Chat", stock: 5, price: 3800, status: "low" },
  { name: "CapCut Pro", category: "Video Editor", stock: 22, price: 1500, status: "in-stock" },
  { name: "Veo 3 Ultra", category: "Video AI", stock: 3, price: 6000, status: "low" },
  { name: "HeyGen Pro", category: "Avatars", stock: 0, price: 5500, status: "out" },
  { name: "Premium VPN", category: "Privacy", stock: 35, price: 3200, status: "in-stock" },
];

function ToolsPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Tools / Inventory" subtitle="Your full catalog of digital products and stock levels" icon={Package}
        actions={<button className="rounded-lg bg-white px-3 py-2 text-sm font-semibold text-black">+ Add tool</button>} />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {TOOLS.map((t) => (
          <Card key={t.name} className="relative overflow-hidden">
            <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-[oklch(0.78_0.15_75)]/10 blur-2xl" />
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="rounded-lg border border-white/10 bg-white/5 p-2.5 text-[oklch(0.85_0.15_75)]">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-display text-base font-bold">{t.name}</p>
                  <p className="text-[11px] uppercase tracking-wider text-white/45">{t.category}</p>
                </div>
              </div>
              <StatusPill label={t.status === "in-stock" ? "In stock" : t.status === "low" ? "Low" : "Out"}
                tone={t.status === "in-stock" ? "success" : t.status === "low" ? "warning" : "danger"} />
            </div>
            <div className="mt-5 flex items-end justify-between">
              <div>
                <p className="font-mono text-[9px] uppercase tracking-wider text-white/45">Price</p>
                <p className="mt-0.5 font-mono text-lg font-bold">{fmtRs(t.price)}</p>
              </div>
              <div className="text-right">
                <p className="font-mono text-[9px] uppercase tracking-wider text-white/45">In stock</p>
                <p className="mt-0.5 font-mono text-lg font-bold">{t.stock}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
