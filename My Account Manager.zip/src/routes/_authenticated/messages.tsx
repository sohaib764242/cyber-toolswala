import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MessageSquare, Send } from "lucide-react";
import { PageHeader, Card } from "@/components/section";

export const Route = createFileRoute("/_authenticated/messages")({ component: MessagesPage });

const THREADS = [
  { id: 1, name: "Ahmed Khan", last: "Thanks! Got the access.", time: "2m", unread: 0 },
  { id: 2, name: "Sara Ali", last: "Account is showing locked again", time: "1h", unread: 2 },
  { id: 3, name: "Bilal Hassan", last: "Can I extend my CapCut?", time: "3h", unread: 1 },
  { id: 4, name: "Hina Raza", last: "Payment sent — please confirm", time: "Yesterday", unread: 0 },
];

const MESSAGES = [
  { from: "them", text: "Hi! Account is showing locked again", time: "10:24" },
  { from: "me", text: "Hey, I'm checking now — give me 2 minutes.", time: "10:25" },
  { from: "me", text: "Done — try logging in fresh, it should work now.", time: "10:31" },
  { from: "them", text: "Yes works! Thank you 🙏", time: "10:33" },
];

function MessagesPage() {
  const [active, setActive] = useState(2);

  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Messages" subtitle="Customer conversations" icon={MessageSquare} />

      <div className="grid gap-0 lg:grid-cols-[300px_1fr]">
        <Card className="!rounded-r-none lg:!border-r-0">
          <p className="mb-3 font-mono text-[10px] uppercase tracking-wider text-white/45">Conversations</p>
          <ul className="-mx-2 space-y-1">
            {THREADS.map((t) => (
              <li key={t.id}>
                <button onClick={() => setActive(t.id)} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition ${active === t.id ? "bg-white/[0.07]" : "hover:bg-white/[0.04]"}`}>
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-xs font-semibold uppercase">{t.name[0]}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-medium">{t.name}</p>
                      <span className="text-[10px] text-white/40">{t.time}</span>
                    </div>
                    <p className="truncate text-xs text-white/50">{t.last}</p>
                  </div>
                  {t.unread > 0 && <span className="rounded-full bg-[oklch(0.65_0.21_27)] px-1.5 py-0.5 text-[10px] font-bold">{t.unread}</span>}
                </button>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="flex flex-col !rounded-l-none">
          <div className="flex items-center gap-3 border-b border-white/10 pb-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-xs font-semibold">S</div>
            <div>
              <p className="text-sm font-medium">Sara Ali</p>
              <p className="text-[11px] text-[oklch(0.78_0.15_155)]">● Online</p>
            </div>
          </div>
          <div className="flex-1 space-y-3 py-4">
            {MESSAGES.map((m, i) => (
              <div key={i} className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[70%] rounded-2xl px-3.5 py-2 text-sm ${m.from === "me" ? "bg-white text-black" : "border border-white/10 bg-white/[0.04]"}`}>
                  {m.text}
                  <span className={`ml-2 text-[10px] ${m.from === "me" ? "text-black/50" : "text-white/40"}`}>{m.time}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 border-t border-white/10 pt-3">
            <input placeholder="Type a message..." className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm placeholder:text-white/40" />
            <button className="rounded-lg bg-white p-2 text-black"><Send className="h-4 w-4" /></button>
          </div>
        </Card>
      </div>
    </div>
  );
}
