import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck, RefreshCw } from "lucide-react";
import { PageHeader, Card, StatusPill, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/replacements")({ component: ReplacementsPage });

const ITEMS = [
  { id: "RPL-204", client: "Sara Ali", product: "ChatGPT Plus", reason: "Account locked", status: "in-progress", date: "2026-05-09", refund: 0 },
  { id: "RPL-203", client: "Bilal Hassan", product: "CapCut Pro", reason: "Login failed", status: "resolved", date: "2026-05-08", refund: 0 },
  { id: "RPL-202", client: "Hina Raza", product: "Premium VPN", reason: "Expired early", status: "in-progress", date: "2026-05-07", refund: 0 },
  { id: "RPL-201", client: "Usman Tariq", product: "HeyGen Pro", reason: "Refund requested", status: "refunded", date: "2026-05-05", refund: 5500 },
];

function ReplacementsPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Account Replacements" subtitle="Track and resolve account issues for your customers" icon={ShieldCheck}
        actions={<button className="inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-sm font-semibold text-black">+ New replacement</button>} />

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 text-left text-[10px] uppercase tracking-wider text-white/45">
                <th className="pb-3 pr-4">Ticket</th>
                <th className="pb-3 pr-4">Client</th>
                <th className="pb-3 pr-4">Product</th>
                <th className="pb-3 pr-4">Reason</th>
                <th className="pb-3 pr-4">Date</th>
                <th className="pb-3 pr-4">Refund</th>
                <th className="pb-3 pr-4">Status</th>
                <th className="pb-3 pr-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ITEMS.map((i) => (
                <tr key={i.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 pr-4 font-mono text-xs text-white/70">{i.id}</td>
                  <td className="py-3 pr-4">{i.client}</td>
                  <td className="py-3 pr-4 text-white/70">{i.product}</td>
                  <td className="py-3 pr-4 text-white/55">{i.reason}</td>
                  <td className="py-3 pr-4 font-mono text-xs text-white/50">{i.date}</td>
                  <td className="py-3 pr-4 font-mono">{i.refund ? fmtRs(i.refund) : "—"}</td>
                  <td className="py-3 pr-4"><StatusPill label={i.status} tone={i.status === "resolved" ? "success" : i.status === "refunded" ? "info" : "warning"} /></td>
                  <td className="py-3 pr-4"><button className="rounded-md border border-white/10 bg-white/5 p-1.5 text-white/60 hover:bg-white/10"><RefreshCw className="h-3.5 w-3.5" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
