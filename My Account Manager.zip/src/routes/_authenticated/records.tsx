import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2, Phone, Pencil, BellRing, Bell, BellOff, FileDown, FileText } from "lucide-react";
import { toast } from "sonner";
import { exportRecordsCSV, exportRecordsPDF } from "@/lib/export-records";

export const Route = createFileRoute("/_authenticated/records")({ component: RecordsPage });

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);

type PayStatus = "paid" | "partial" | "unpaid";

const statusStyles: Record<PayStatus, string> = {
  paid: "bg-success/15 text-success",
  partial: "bg-accent/20 text-accent-foreground",
  unpaid: "bg-destructive/15 text-destructive",
};

type FormState = {
  name: string;
  mobile: string;
  to_pay: string;
  to_receive: string;
  invoices_sent: string;
  payment_received: string;
  payment_status: PayStatus;
  account: string;
  payment_method: string;
  tool: string;
  reminder_date: string;
  reminder_note: string;
  notes: string;
};

const empty = (): FormState => ({
  name: "", mobile: "", to_pay: "0", to_receive: "0",
  invoices_sent: "0", payment_received: "0", payment_status: "unpaid",
  account: "", payment_method: "", tool: "",
  reminder_date: "", reminder_note: "", notes: "",
});

const PAYMENT_METHODS = ["Cash", "Bank Transfer", "Credit Card", "Debit Card", "PayPal", "Venmo", "Stripe", "Check", "Crypto", "Other"] as const;
const TOOLS = ["CapCut Pro", "Grok", "Veo 3 Ultra", "ChatGPT", "Gemini", "HeyGen", "VPNs"] as const;

const todayStr = () => new Date().toISOString().slice(0, 10);

const reminderState = (d: string | null | undefined): "overdue" | "today" | "upcoming" | "none" => {
  if (!d) return "none";
  const t = todayStr();
  if (d < t) return "overdue";
  if (d === t) return "today";
  return "upcoming";
};

const reminderStyles: Record<"overdue" | "today" | "upcoming" | "none", string> = {
  overdue: "bg-destructive/15 text-destructive",
  today: "bg-accent/20 text-accent-foreground",
  upcoming: "bg-muted text-muted-foreground",
  none: "",
};

function RecordsPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(empty());

  const { data: records = [], isLoading } = useQuery({
    queryKey: ["records", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("records").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.name.trim()) throw new Error("Name required");
      const payload = {
        user_id: user!.id,
        name: form.name.trim(),
        mobile: form.mobile.trim() || null,
        to_pay: Number(form.to_pay) || 0,
        to_receive: Number(form.to_receive) || 0,
        invoices_sent: parseInt(form.invoices_sent) || 0,
        payment_received: Number(form.payment_received) || 0,
        payment_status: form.payment_status,
        account: form.account.trim() || null,
        payment_method: form.payment_method.trim() || null,
        tool: form.tool.trim() || null,
        reminder_date: form.reminder_date || null,
        reminder_note: form.reminder_note.trim() || null,
        notes: form.notes.trim() || null,
      };
      if (editingId) {
        const { error } = await supabase.from("records").update(payload).eq("id", editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("records").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(editingId ? "Record updated" : "Record added");
      setForm(empty()); setEditingId(null); setOpen(false);
      qc.invalidateQueries({ queryKey: ["records"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, payment_status }: { id: string; payment_status: PayStatus }) => {
      const { error } = await supabase.from("records").update({ payment_status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["records"] }),
  });

  const clearReminder = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("records")
        .update({ reminder_date: null, reminder_note: null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Reminder cleared");
      qc.invalidateQueries({ queryKey: ["records"] });
    },
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("records").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Removed");
      qc.invalidateQueries({ queryKey: ["records"] });
    },
  });

  const startEdit = (r: any) => {
    setEditingId(r.id);
    setForm({
      name: r.name, mobile: r.mobile ?? "",
      to_pay: String(r.to_pay), to_receive: String(r.to_receive),
      invoices_sent: String(r.invoices_sent),
      payment_received: String(r.payment_received),
      payment_status: (r.payment_status ?? "unpaid") as PayStatus,
      account: r.account ?? "",
      payment_method: r.payment_method ?? "",
      tool: r.tool ?? "",
      reminder_date: r.reminder_date ?? "",
      reminder_note: r.reminder_note ?? "",
      notes: r.notes ?? "",
    });
    setOpen(true);
  };

  const totals = records.reduce(
    (a, r) => ({
      pay: a.pay + Number(r.to_pay),
      receive: a.receive + Number(r.to_receive),
      received: a.received + Number(r.payment_received),
      invoices: a.invoices + r.invoices_sent,
    }),
    { pay: 0, receive: 0, received: 0, invoices: 0 },
  );

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">Folio · Records</p>
          <h1 className="mt-1 text-3xl font-bold md:text-4xl">Records</h1>
          <p className="mt-1 text-sm text-muted-foreground">Track payables, receivables and contacts.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled={records.length === 0}
            onClick={() => exportRecordsCSV(records as any)}>
            <FileDown className="mr-2 h-4 w-4" /> CSV
          </Button>
          <Button variant="outline" size="sm" disabled={records.length === 0}
            onClick={() => exportRecordsPDF(records as any)}>
            <FileText className="mr-2 h-4 w-4" /> PDF
          </Button>
          <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setEditingId(null); setForm(empty()); } }}>
            <DialogTrigger asChild>
              <Button><Plus className="mr-2 h-4 w-4" /> New record</Button>
            </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editingId ? "Edit record" : "New record"}</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Name *"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
                <Field label="Mobile number"><Input type="tel" placeholder="+1 555 0100" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Need to pay (you owe)"><Input type="number" step="0.01" value={form.to_pay} onChange={(e) => setForm({ ...form, to_pay: e.target.value })} /></Field>
                <Field label="To be paid (owed to you)"><Input type="number" step="0.01" value={form.to_receive} onChange={(e) => setForm({ ...form, to_receive: e.target.value })} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Invoices sent"><Input type="number" min="0" step="1" value={form.invoices_sent} onChange={(e) => setForm({ ...form, invoices_sent: e.target.value })} /></Field>
                <Field label="Payment received"><Input type="number" step="0.01" value={form.payment_received} onChange={(e) => setForm({ ...form, payment_received: e.target.value })} /></Field>
              </div>
              <Field label="Payment status">
                <Select value={form.payment_status} onValueChange={(v: PayStatus) => setForm({ ...form, payment_status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(["paid", "partial", "unpaid"] as PayStatus[]).map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Account">
                  <Input placeholder="e.g. Chase Checking" value={form.account} onChange={(e) => setForm({ ...form, account: e.target.value })} />
                </Field>
                <Field label="Payment method">
                  <Select value={form.payment_method || "__none"} onValueChange={(v) => setForm({ ...form, payment_method: v === "__none" ? "" : v })}>
                    <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none">— None —</SelectItem>
                      {PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Field>
              </div>
              <Field label="Tool">
                <Select value={form.tool || "__none"} onValueChange={(v) => setForm({ ...form, tool: v === "__none" ? "" : v })}>
                  <SelectTrigger><SelectValue placeholder="Select tool" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">— None —</SelectItem>
                    {TOOLS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Reminder date">
                  <Input type="date" value={form.reminder_date} onChange={(e) => setForm({ ...form, reminder_date: e.target.value })} />
                </Field>
                <Field label="Reminder note">
                  <Input placeholder="Call to follow up" value={form.reminder_note} onChange={(e) => setForm({ ...form, reminder_note: e.target.value })} />
                </Field>
              </div>
              <Field label="Notes"><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => save.mutate()} disabled={save.isPending}>{editingId ? "Update" : "Save"}</Button>
            </DialogFooter>
          </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <SummaryCard label="You owe" value={fmt(totals.pay)} />
        <SummaryCard label="Owed to you" value={fmt(totals.receive)} />
        <SummaryCard label="Received" value={fmt(totals.received)} />
        <SummaryCard label="Invoices sent" value={String(totals.invoices)} />
      </div>

      {(() => {
        const upcoming = records
          .filter((r) => r.reminder_date && (r.payment_status ?? "unpaid") !== "paid")
          .sort((a, b) => (a.reminder_date! < b.reminder_date! ? -1 : 1))
          .slice(0, 6);
        if (upcoming.length === 0) return null;
        return (
          <div className="ledger-card mt-6 rounded-lg p-5">
            <div className="mb-3 flex items-center gap-2">
              <BellRing className="h-4 w-4 text-accent-foreground" />
              <h2 className="font-display text-lg font-semibold">Follow-ups</h2>
              <span className="font-mono text-xs text-muted-foreground">{upcoming.length}</span>
            </div>
            <ul className="space-y-2">
              {upcoming.map((r) => {
                const s = reminderState(r.reminder_date);
                return (
                  <li key={r.id} className="flex items-center justify-between gap-3 rounded-md border border-border/60 px-3 py-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{r.name}</p>
                      {r.reminder_note && <p className="truncate text-xs text-muted-foreground">{r.reminder_note}</p>}
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <span className={`rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${reminderStyles[s]}`}>
                        {s === "overdue" ? `Overdue · ${r.reminder_date}` : s === "today" ? "Today" : r.reminder_date}
                      </span>
                      <button onClick={() => clearReminder.mutate(r.id)} title="Clear reminder"
                        className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground">
                        <BellOff className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })()}

      <div className="ledger-card mt-8 overflow-hidden rounded-lg">
        {isLoading ? (
          <p className="p-6 text-sm text-muted-foreground">Loading…</p>
        ) : records.length === 0 ? (
          <div className="p-12 text-center">
            <p className="font-display text-lg font-semibold">No records yet</p>
            <p className="mt-1 text-sm text-muted-foreground">Add your first entry above.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Name</th>
                  <th className="px-4 py-3 text-left">Mobile</th>
                  <th className="px-4 py-3 text-left">Account</th>
                  <th className="px-4 py-3 text-right">You owe</th>
                  <th className="px-4 py-3 text-right">Owed to you</th>
                  <th className="px-4 py-3 text-right">Invoices</th>
                  <th className="px-4 py-3 text-right">Received</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  <th className="px-4 py-3 text-left">Reminder</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {records.map((r) => (
                  <tr key={r.id} className="hover:bg-muted/30">
                    <td className="px-4 py-3 font-medium">
                      {r.name}
                      {r.notes && <p className="text-xs text-muted-foreground">{r.notes}</p>}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {r.mobile ? (
                        <a href={`tel:${r.mobile}`} className="inline-flex items-center gap-1 hover:text-foreground">
                          <Phone className="h-3 w-3" /> {r.mobile}
                        </a>
                      ) : "—"}
                    </td>
                    <td className="px-4 py-3">
                      {r.account || r.payment_method || r.tool ? (
                        <div className="flex flex-col">
                          {r.tool && <span className="text-sm font-medium">{r.tool}</span>}
                          {r.account && <span className="text-sm">{r.account}</span>}
                          {r.payment_method && (
                            <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{r.payment_method}</span>
                          )}
                        </div>
                      ) : <span className="text-muted-foreground">—</span>}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-destructive">{fmt(Number(r.to_pay))}</td>
                    <td className="px-4 py-3 text-right font-mono text-success">{fmt(Number(r.to_receive))}</td>
                    <td className="px-4 py-3 text-right font-mono">{r.invoices_sent}</td>
                    <td className="px-4 py-3 text-right font-mono">{fmt(Number(r.payment_received))}</td>
                    <td className="px-4 py-3">
                      <Select
                        value={(r.payment_status ?? "unpaid") as PayStatus}
                        onValueChange={(v: PayStatus) => updateStatus.mutate({ id: r.id, payment_status: v })}
                      >
                        <SelectTrigger className={`h-7 w-28 border-0 px-2 text-xs uppercase tracking-wider ${statusStyles[(r.payment_status ?? "unpaid") as PayStatus]}`}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {(["paid", "partial", "unpaid"] as PayStatus[]).map((s) => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="px-4 py-3">
                      {r.reminder_date ? (
                        <div className="flex items-center gap-1.5">
                          <span className={`rounded px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider ${reminderStyles[reminderState(r.reminder_date)]}`}>
                            {r.reminder_date}
                          </span>
                          {r.reminder_note && (
                            <span className="truncate text-xs text-muted-foreground" title={r.reminder_note}>
                              {r.reminder_note}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground/60">
                          <Bell className="h-3 w-3" /> —
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => startEdit(r)} className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button onClick={() => { if (confirm(`Remove ${r.name}?`)) remove.mutate(r.id); }}
                          className="rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><Label className="mb-1 block">{label}</Label>{children}</div>;
}

function SummaryCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="ledger-card rounded-lg p-4">
      <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{label}</p>
      <p className="mt-1 font-mono text-xl font-semibold">{value}</p>
    </div>
  );
}
