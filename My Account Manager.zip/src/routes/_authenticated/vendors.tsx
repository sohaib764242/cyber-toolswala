import { createFileRoute } from "@tanstack/react-router";
import { Building2, Search, Edit2, Trash2 } from "lucide-react";
import { PageHeader, Card, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/vendors")({ component: VendorsPage });

const VENDORS = [
  { name: "Sahazaib", phone: "+923467372689", dues: 0, supplies: "ChatGPT, Gemini" },
  { name: "Work Easy Tool", phone: "+923467372689", dues: 4200, supplies: "CapCut, Veo 3" },
  { name: "Anas", phone: "03023656605", dues: 0, supplies: "VPN bundle" },
  { name: "DigitalHub", phone: "03124567890", dues: 1800, supplies: "HeyGen, Grok" },
];

function VendorsPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Vendor Management" subtitle="Coordinate with suppliers and manage inventory sourcing" icon={Building2}
        actions={
          <div className="flex rounded-lg border border-white/10 bg-white/5 p-0.5 text-xs">
            <button className="rounded-md bg-white/10 px-3 py-1.5 text-white">Card view</button>
            <button className="px-3 py-1.5 text-white/60">List view</button>
            <button className="px-3 py-1.5 text-white/60">Export CSV</button>
          </div>
        } />

      <Card className="mb-5">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-white/55">+ Register new supply partner</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-4">
          <input placeholder="Vendor name" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder:text-white/40" />
          <input placeholder="Contact number" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder:text-white/40" />
          <select className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white"><option>Choose tool…</option></select>
          <button className="rounded-lg bg-white px-3 py-2 text-sm font-semibold text-black">+ Add vendor</button>
        </div>
      </Card>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
        <input placeholder="Search vendors..." className="w-full rounded-lg border border-white/10 bg-white/5 py-2.5 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-white/30 focus:outline-none" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {VENDORS.map((v) => (
          <Card key={v.name}>
            <div className="flex items-start justify-between">
              <div>
                <p className="font-display text-lg font-bold">{v.name}</p>
                <p className="text-xs text-white/45">{v.phone}</p>
                <p className="mt-1 text-[11px] text-white/55">Supplies: {v.supplies}</p>
              </div>
              <div className="flex gap-1">
                <button className="rounded-md border border-white/10 bg-white/5 p-1.5 text-[oklch(0.78_0.15_280)] hover:bg-white/10"><Edit2 className="h-3.5 w-3.5" /></button>
                <button className="rounded-md border border-white/10 bg-white/5 p-1.5 text-[oklch(0.78_0.21_27)] hover:bg-white/10"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
            <div className="mt-4 flex items-end justify-between rounded-lg border border-white/10 bg-white/[0.02] p-3">
              <div>
                <p className="font-mono text-[9px] uppercase tracking-wider text-white/45">Pending Dues</p>
                <p className={`mt-0.5 font-mono text-base font-bold ${v.dues > 0 ? "text-[oklch(0.78_0.21_27)]" : ""}`}>{fmtRs(v.dues)}</p>
              </div>
              <button className="rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] hover:bg-white/10">Manage dues</button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
