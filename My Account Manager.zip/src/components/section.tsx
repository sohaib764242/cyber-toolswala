import type { ReactNode } from "react";
import { type LucideIcon } from "lucide-react";

export function PageHeader({
  title,
  subtitle,
  icon: Icon,
  actions,
}: {
  title: string;
  subtitle?: string;
  icon?: LucideIcon;
  actions?: ReactNode;
}) {
  return (
    <header className="mb-6 rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          {Icon && (
            <div className="rounded-xl border border-white/10 bg-white/5 p-2.5 text-[oklch(0.78_0.15_75)]">
              <Icon className="h-5 w-5" />
            </div>
          )}
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight">{title}</h1>
            {subtitle && <p className="mt-0.5 text-sm text-white/55">{subtitle}</p>}
          </div>
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </header>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur ${className}`}>
      {children}
    </div>
  );
}

export function StatCard({
  label,
  value,
  hint,
  tone = "default",
  icon: Icon,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "success" | "danger" | "accent" | "violet";
  icon?: LucideIcon;
}) {
  const toneMap: Record<string, string> = {
    default: "text-white",
    success: "text-[oklch(0.78_0.15_155)]",
    danger: "text-[oklch(0.72_0.21_27)]",
    accent: "text-[oklch(0.85_0.15_75)]",
    violet: "text-[oklch(0.75_0.18_280)]",
  };
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur transition hover:border-white/20">
      <div className="flex items-start justify-between">
        <p className="text-[11px] font-medium uppercase tracking-[0.15em] text-white/45">{label}</p>
        {Icon && <Icon className="h-4 w-4 text-white/30" />}
      </div>
      <p className={`mt-3 font-mono text-2xl font-bold ${toneMap[tone]}`}>{value}</p>
      {hint && <p className="mt-1 text-xs text-white/45">{hint}</p>}
    </div>
  );
}

export function StatusPill({
  label,
  tone = "neutral",
}: {
  label: string;
  tone?: "neutral" | "success" | "danger" | "warning" | "info";
}) {
  const toneMap: Record<string, string> = {
    neutral: "bg-white/10 text-white/70",
    success: "bg-[oklch(0.65_0.13_155)]/15 text-[oklch(0.78_0.15_155)]",
    danger: "bg-[oklch(0.65_0.21_27)]/15 text-[oklch(0.78_0.21_27)]",
    warning: "bg-[oklch(0.78_0.15_75)]/15 text-[oklch(0.85_0.15_75)]",
    info: "bg-[oklch(0.55_0.18_280)]/15 text-[oklch(0.78_0.15_280)]",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${toneMap[tone]}`}>
      {label}
    </span>
  );
}

export const fmtRs = (n: number) =>
  "Rs. " + new Intl.NumberFormat("en-PK", { maximumFractionDigits: 0 }).format(n);
