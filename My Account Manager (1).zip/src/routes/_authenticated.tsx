import { createFileRoute, Outlet, Link, Navigate, useRouterState, useNavigate } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import { useIsAdmin } from "@/hooks/use-is-admin";
import {
  LayoutDashboard,
  BarChart3,
  ShoppingCart,
  PlusCircle,
  ShieldCheck,
  AlertTriangle,
  Building2,
  Package,
  History,
  MessageSquare,
  CreditCard,
  Users,
  Undo2,
  Wallet,
  LogOut,
  Loader2,
  PanelLeft,
} from "lucide-react";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/_authenticated")({ component: AuthLayout });

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard; badge?: number };
type NavGroup = { label: string; items: NavItem[] };

const groups: NavGroup[] = [
  {
    label: "Main",
    items: [
      { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
      { to: "/analytics", label: "Analytics", icon: BarChart3 },
      { to: "/orders", label: "Orders", icon: ShoppingCart, badge: 2 },
      { to: "/new-sale", label: "New Sale", icon: PlusCircle },
      { to: "/replacements", label: "Account Replacements", icon: ShieldCheck },
      { to: "/expiry", label: "Expiry Alerts", icon: AlertTriangle },
    ],
  },
  {
    label: "Inventory",
    items: [
      { to: "/vendors", label: "Vendors", icon: Building2 },
      { to: "/tools", label: "Tools / Inventory", icon: Package },
    ],
  },
  {
    label: "Records",
    items: [
      { to: "/sales-history", label: "Sales History", icon: History },
      { to: "/messages", label: "Messages", icon: MessageSquare },
      { to: "/pending-payments", label: "Pending Payments", icon: CreditCard, badge: 1 },
      { to: "/customers", label: "Customers", icon: Users },
    ],
  },
  {
    label: "Finance",
    items: [
      { to: "/refunds", label: "Customer Refunds", icon: Undo2 },
      { to: "/accounts", label: "Payments & Accounts", icon: Wallet },
    ],
  },
];

function AuthLayout() {
  const { user, loading, signOut } = useAuth();
  const { isAdmin } = useIsAdmin();
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });

  const navGroups = isAdmin
    ? [...groups, { label: "Admin", items: [{ to: "/admin", label: "All Users", icon: ShieldCheck }] }]
    : groups;

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[oklch(0.16_0.025_255)]">
        <Loader2 className="h-6 w-6 animate-spin text-white/50" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" />;

  return (
    <div className="flex min-h-screen w-full bg-[oklch(0.16_0.025_255)] text-[oklch(0.95_0.012_85)]">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-white/5 bg-[oklch(0.13_0.02_255)] md:flex">
        <div className="flex items-center gap-3 px-5 py-5">
          <img src={logo} alt="" className="h-10 w-10 rounded-lg object-cover ring-1 ring-white/10" />
          <div>
            <p className="font-display text-sm font-bold leading-tight">Cyber Tools Store</p>
            <p className="text-[11px] text-white/40">Made with care</p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-4">
          {groups.map((group) => (
            <div key={group.label}>
              <p className="mb-2 px-3 font-mono text-[10px] uppercase tracking-[0.18em] text-white/35">
                {group.label}
              </p>
              <div className="space-y-0.5">
                {group.items.map(({ to, label, icon: Icon, badge }) => {
                  const active = path === to;
                  return (
                    <Link
                      key={to}
                      to={to}
                      className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                        active
                          ? "bg-white/[0.07] text-white"
                          : "text-white/60 hover:bg-white/[0.04] hover:text-white"
                      }`}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span className="flex-1 truncate">{label}</span>
                      {badge !== undefined && (
                        <span className="rounded-full bg-[oklch(0.65_0.21_27)]/80 px-1.5 py-0.5 text-[10px] font-semibold text-white">
                          {badge}
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="border-t border-white/5 p-3">
          <Link to="/profile" className="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-white/[0.04]">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-xs font-semibold uppercase">
              {user.email?.[0] ?? "U"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-medium text-white/85">My Profile</p>
              <p className="truncate text-[10px] text-white/40">{user.email}</p>
            </div>
          </Link>
          <button
            onClick={async () => { await signOut(); navigate({ to: "/" }); }}
            className="mt-2 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-white/60 hover:bg-white/[0.04] hover:text-white"
          >
            <LogOut className="h-4 w-4" /> Logout
          </button>
        </div>
      </aside>

      <div className="flex w-full flex-col">
        <header className="flex items-center justify-between border-b border-white/5 bg-[oklch(0.13_0.02_255)] px-4 py-3 md:hidden">
          <Link to="/dashboard" className="flex items-center gap-2">
            <img src={logo} alt="" className="h-8 w-8 rounded-md object-cover" />
            <span className="font-display font-bold">Cyber Tools Store</span>
          </Link>
          <button onClick={async () => { await signOut(); navigate({ to: "/" }); }} className="rounded-md p-2 text-white/60">
            <LogOut className="h-4 w-4" />
          </button>
        </header>

        {/* Mobile horizontal nav */}
        <nav className="flex gap-1 overflow-x-auto border-b border-white/5 bg-[oklch(0.13_0.02_255)] px-3 py-2 md:hidden">
          {groups.flatMap((g) => g.items).map(({ to, label, icon: Icon }) => {
            const active = path === to;
            return (
              <Link
                key={to}
                to={to}
                className={`flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs ${
                  active ? "bg-white/10 text-white" : "text-white/55"
                }`}
              >
                <Icon className="h-3.5 w-3.5" /> {label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center justify-between border-b border-white/5 px-8 py-3 md:flex">
          <button className="rounded-md p-1.5 text-white/50 hover:bg-white/5 hover:text-white">
            <PanelLeft className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-2 text-xs text-white/45">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-[oklch(0.65_0.13_155)]" />
            System Operational — Real-time data active
          </div>
        </div>

        <main className="flex-1 px-4 py-6 md:px-8 md:py-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
