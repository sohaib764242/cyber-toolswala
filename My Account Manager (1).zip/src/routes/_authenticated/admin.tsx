import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ShieldCheck, Loader2, Mail, User as UserIcon, Phone } from "lucide-react";
import { listAllUsers } from "@/lib/admin.functions";
import { useIsAdmin } from "@/hooks/use-is-admin";
import { PageHeader, Card, fmtRs } from "@/components/section";

export const Route = createFileRoute("/_authenticated/admin")({ component: AdminPage });

function AdminPage() {
  const { isAdmin, loading: roleLoading } = useIsAdmin();
  const fetchUsers = useServerFn(listAllUsers);

  const { data: users = [], isLoading, error } = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => fetchUsers(),
    enabled: isAdmin,
  });

  if (roleLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-white/50" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-md rounded-xl border border-white/10 bg-white/[0.03] p-8 text-center">
        <ShieldCheck className="mx-auto h-10 w-10 text-white/30" />
        <h2 className="mt-3 font-display text-xl font-bold">Admins only</h2>
        <p className="mt-1 text-sm text-white/55">You don't have permission to view this page.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Admin · Users" subtitle="All registered users on the platform" icon={ShieldCheck} />

      {isLoading ? (
        <div className="flex h-40 items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-white/50" />
        </div>
      ) : error ? (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">
          {(error as Error).message}
        </div>
      ) : (
        <div className="grid gap-3">
          {users.map((u) => {
            const isAdminUser = u.roles.includes("admin");
            return (
              <Card key={u.id}>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-sm font-semibold uppercase">
                      {(u.displayName || u.email)[0]}
                    </div>
                    <div>
                      <p className="flex items-center gap-2 font-display font-bold">
                        <UserIcon className="h-3.5 w-3.5 text-white/40" />
                        {u.displayName || u.email.split("@")[0]}
                        {isAdminUser && (
                          <span className="rounded-full bg-[oklch(0.72_0.13_70)]/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[oklch(0.85_0.15_75)]">
                            Admin
                          </span>
                        )}
                      </p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-xs text-white/55">
                        <Mail className="h-3 w-3" />
                        {u.email}
                      </p>
                      {u.phone && (
                        <p className="mt-0.5 flex items-center gap-1.5 text-xs text-white/45">
                          <Phone className="h-3 w-3" />
                          {u.phone}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-4 gap-3 text-center text-xs">
                    <Stat label="Records" value={String(u.recordCount)} />
                    <Stat label="Received" value={fmtRs(u.totals.received)} />
                    <Stat label="To Receive" value={fmtRs(u.totals.toReceive)} />
                    <Stat label="To Pay" value={fmtRs(u.totals.toPay)} />
                  </div>
                </div>
                <p className="mt-3 text-[10px] text-white/35">
                  Joined {new Date(u.createdAt).toLocaleDateString()} ·{" "}
                  {u.lastSignIn ? `Last sign-in ${new Date(u.lastSignIn).toLocaleString()}` : "Never signed in"}
                </p>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2">
      <p className="font-mono text-sm font-bold">{value}</p>
      <p className="text-[10px] uppercase tracking-wider text-white/45">{label}</p>
    </div>
  );
}
