import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const listAllUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    // Verify caller is admin
    const { data: roleRow } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) throw new Error("Forbidden");

    // List auth users (admin)
    const { data: usersData, error: usersErr } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 200,
    });
    if (usersErr) throw usersErr;

    const userIds = usersData.users.map((u) => u.id);
    const [{ data: profiles }, { data: roles }, { data: records }] = await Promise.all([
      supabaseAdmin.from("profiles").select("user_id, display_name, phone").in("user_id", userIds),
      supabaseAdmin.from("user_roles").select("user_id, role").in("user_id", userIds),
      supabaseAdmin
        .from("records")
        .select("user_id, payment_received, to_receive, to_pay")
        .in("user_id", userIds),
    ]);

    return usersData.users.map((u) => {
      const p = profiles?.find((x) => x.user_id === u.id);
      const userRoles = roles?.filter((r) => r.user_id === u.id).map((r) => r.role) ?? [];
      const userRecords = records?.filter((r) => r.user_id === u.id) ?? [];
      const totals = userRecords.reduce(
        (acc, r: any) => {
          acc.received += Number(r.payment_received || 0);
          acc.toReceive += Number(r.to_receive || 0);
          acc.toPay += Number(r.to_pay || 0);
          return acc;
        },
        { received: 0, toReceive: 0, toPay: 0 },
      );
      return {
        id: u.id,
        email: u.email ?? "",
        createdAt: u.created_at,
        lastSignIn: u.last_sign_in_at ?? null,
        displayName: p?.display_name ?? null,
        phone: p?.phone ?? null,
        roles: userRoles,
        recordCount: userRecords.length,
        totals,
      };
    });
  });
